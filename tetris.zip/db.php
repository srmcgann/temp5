<?php
  //error_reporting(0);
  $db_user  = 'id21257390_user';
  //$db_user  = 'id21269596_user';
  $db_pass  = 'Chrome57253!*';
  $db_host  = 'localhost';
  $db       = "id21257390_default";
  //$db       = "id21269596_videodemos";
  $port     = '3306';
  $link     = mysqli_connect($db_host,$db_user,$db_pass,$db,$port);

  $baseURL  = "http://efx.cantelope.org/b/games/tetris";
  $link     = mysqli_connect($db_host,$db_user,$db_pass,$db,$port);
?>
